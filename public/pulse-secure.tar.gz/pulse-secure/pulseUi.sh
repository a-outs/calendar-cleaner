#!/bin/sh

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/pulse
exec /usr/local/pulse/pulseUi
